#include <xc.h>
#include "lcd.h"
#define _XTAL_FREQ 20000000

void Lcd_Init() {
    TRISD = 0x00; // Set PORTD as output
    Lcd_Cmd(0x02); // 4-bit mode
    Lcd_Cmd(0x28); // 2-line, 5x7 matrix
    Lcd_Cmd(0x0C); // Display ON, Cursor OFF
    Lcd_Cmd(0x06); // Increment cursor
    Lcd_Cmd(0x01); // Clear display
}

void Lcd_Cmd(char cmd) {
    RS = 0;
    
    D4 = (cmd >> 4) & 1;
    D5 = (cmd >> 5) & 1;
    D6 = (cmd >> 6) & 1;
    D7 = (cmd >> 7) & 1;
    
    EN = 1;
    __delay_ms(2);
    EN = 0;
    
    D4 = cmd & 1;
    D5 = (cmd >> 1) & 1;
    D6 = (cmd >> 2) & 1;
    D7 = (cmd >> 3) & 1;
    
    EN = 1;
    __delay_ms(2);
    EN = 0;
}

void Lcd_Clear() {
    Lcd_Cmd(0x01);
}

void Lcd_Set_Cursor(char row, char column) {
    char pos;
    pos = (row == 1) ? (0x80 + column - 1) : (0xC0 + column - 1);
    Lcd_Cmd(pos);
}

void Lcd_Write_Char(char data) {
    RS = 1;
    
    D4 = (data >> 4) & 1;
    D5 = (data >> 5) & 1;
    D6 = (data >> 6) & 1;
    D7 = (data >> 7) & 1;
    
    EN = 1;
    __delay_ms(2);
    EN = 0;
    
    D4 = data & 1;
    D5 = (data >> 1) & 1;
    D6 = (data >> 2) & 1;
    D7 = (data >> 3) & 1;
    
    EN = 1;
    __delay_ms(2);
    EN = 0;
}

void Lcd_Write_String(char *str) {
    while(*str)
        Lcd_Write_Char(*str++);
}
