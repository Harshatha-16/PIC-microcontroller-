# PIC16F877A LCD Interfacing (16x2) - 4-bit Mode

This project demonstrates how to interface a 16x2 LCD display with the **PIC16F877A microcontroller** using **MPLAB X IDE** and the **XC8 compiler**. The LCD is operated in **4-bit mode** to save I/O pins.

---

## Features

- Initializes a 16x2 character LCD
- Displays messages on both lines
- Simple and modular code (separate `lcd.c` and `lcd.h`)

---

## Hardware Used

- PIC16F877A Microcontroller
- 16x2 LCD Display
- 20 MHz Crystal Oscillator
- Breadboard, connecting wires, resistors, potentiometer (for contrast)
- Power Supply (5V)

---

## Pin Configuration

| LCD Pin | PIC16F877A Pin |
|---------|----------------|
| RS      | RD0            |
| EN      | RD1            |
| D4      | RD2            |
| D5      | RD3            |
| D6      | RD4            |
| D7      | RD5            |

> Note: Connect RW of LCD to GND (write mode only)

---

## Setup Instructions

1. Open the project in MPLAB X.
2. Make sure your compiler is set to **XC8**.
3. Connect the hardware as per the pin configuration.
4. Build and upload the HEX file to the PIC microcontroller.
5. You should see "Hello, PIC!" and "LCD Interface" on the LCD.

---

## Code Files

- `main.c`: Initializes LCD and displays messages.
- `lcd.h`: LCD function declarations and pin macros.
- `lcd.c`: Function definitions for LCD commands and data writing.

---

## Screenshots

(Add a photo of your setup and LCD output here if possible.)

---

## License

This project is open-source and free to use under the MIT License.

---

## Author

**V P Harshatha**  
[GitHub Profile](https://github.com/Harshatha-16)


## Circuit Diagram

![Circuit Diagram](circuit_diagram.png)
