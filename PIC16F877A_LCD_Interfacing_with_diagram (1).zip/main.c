#include <xc.h>
#include "lcd.h"

// CONFIG
#pragma config FOSC = HS    // High-Speed Oscillator
#pragma config WDTE = OFF   // Watchdog Timer Disable
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 20000000  // 20 MHz crystal

void main(void) {
    Lcd_Init();              // Initialize LCD
    Lcd_Set_Cursor(1,1);     // Set cursor to row 1, column 1
    Lcd_Write_String("Hello, PIC!");
    Lcd_Set_Cursor(2,1);
    Lcd_Write_String("LCD Interface");
    
    while(1);
}
