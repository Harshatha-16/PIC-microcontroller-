#ifndef LCD_H
#define LCD_H

#define RS RD0
#define EN RD1
#define D4 RD2
#define D5 RD3
#define D6 RD4
#define D7 RD5

void Lcd_Init();
void Lcd_Cmd(char);
void Lcd_Clear();
void Lcd_Set_Cursor(char, char);
void Lcd_Write_Char(char);
void Lcd_Write_String(char*);

#endif
